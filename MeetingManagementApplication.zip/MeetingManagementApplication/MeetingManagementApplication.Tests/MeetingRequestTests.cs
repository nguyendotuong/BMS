﻿using AutoFixture;
using AutoFixture.AutoNSubstitute;
using FluentAssertions;
using MeetingManagementApplication.Domain;
using System.Collections.Generic;
using Xunit;

namespace MeetingManagementApplication.Tests.Domain
{
    public class MeetingRequestTests
    {
        private readonly IFixture _fixture;
        private readonly List<MeetingRequest> _meetingRequests;

        public MeetingRequestTests()
        {
            _fixture = new Fixture().Customize(new AutoNSubstituteCustomization());

            var meetingRequest1 = _fixture.Build<MeetingRequest>()
                .With(x => x.StartDateTime, new System.DateTime(2020, 3, 20, 9, 0, 0))
                .With(x => x.DurationInHour, 2)
                .Create();

            var meetingRequest2 = _fixture.Build<MeetingRequest>()
               .With(x => x.StartDateTime, new System.DateTime(2020, 3, 20, 14, 0, 0))
               .With(x => x.DurationInHour, 2)
               .Create();

            _meetingRequests = new List<MeetingRequest> { meetingRequest1, meetingRequest2 };
        }

        [Theory]
        [InlineData(2020, 3, 20, 10, 0, 2, false)]
        [InlineData(2020, 3, 20, 11, 0, 2, true)]
        [InlineData(2020, 3, 20, 11, 0, 5, false)]
        [InlineData(2020, 3, 20, 16, 0, 1, true)]
        [InlineData(2020, 3, 20, 15, 30, 1, false)]
        public void IsNotOverlapIn_ShouldReturnExpectedData(
            int year,
            int month,
            int day,
            int hour,
            int minute,
            int durationInHour,
            bool expected)
        {
            // Arrange
            var meetingRequest = _fixture.Build<MeetingRequest>()
                .With(x => x.StartDateTime, new System.DateTime(year, month, day, hour, minute, 0))
                .With(x => x.DurationInHour, durationInHour)
                .Create();

            // Act
            var actual = meetingRequest.IsNotOverlapIn(_meetingRequests);

            // Assert
            actual.Should().Be(expected);
        }
    }
}
