﻿using MeetingManagementApplication.Domain;
using System.Collections.Generic;

namespace MeetingManagementApplication.Application
{
    public interface IBookingService
    {
        public IEnumerable<BatchMeetingResponses> ProcessBooking(string fileName);

        public void DisplayMeetingRequests(IEnumerable<BatchMeetingResponses> batchMeetingResponses);
    }
}
