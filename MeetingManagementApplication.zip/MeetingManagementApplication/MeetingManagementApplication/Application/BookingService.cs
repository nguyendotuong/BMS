﻿using EnsureThat;
using MeetingManagementApplication.Domain;
using MeetingManagementApplication.Infastructure;
using MeetingManagementApplication.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MeetingManagementApplication.Application
{
    public class BookingService : IBookingService
    {
        private readonly IValidator _validator;

        public BookingService(IValidator validator)
        {
            _validator = validator;
        }

        public IEnumerable<BatchMeetingResponses> ProcessBooking(string fileName)
        {
            Ensure.That(fileName, nameof(fileName)).IsNotNullOrWhiteSpace();

            if (!_validator.ValidateFile(
                fileName,
                out string errorMessage,
                out TimeSpan workingStartTime,
                out TimeSpan workingEndTime,
                out List<string> requestsContents))
            {
                throw new ArgumentException($"{errorMessage}");
            }

            var batchMeetingResponses = new List<BatchMeetingResponses>();
            var splittedMeetingRequests = requestsContents.SplitList(Constants.MeetingRequestNumberOfLines);

            if (splittedMeetingRequests.Any())
            {
                var meetingRequests = new List<MeetingRequest>();

                foreach (var meetingRequestContents in splittedMeetingRequests)
                {
                    if (_validator.ValidateMeetingRequestContents(
                        meetingRequestContents,
                        out string employeeId,
                        out DateTime submission,
                        out DateTime startTime,
                        out int durationInHour))
                    {
                        var meetingRequest = new MeetingRequest(
                            employeeId,
                            submission,
                            startTime,
                            durationInHour);

                        if (meetingRequest.IsValidMeeting(workingStartTime, workingEndTime))
                        {
                            meetingRequests.Add(meetingRequest);
                        }
                    }

                }

                // filter meetingRequests
                var sortedMeetingRequests = SortMeetingRequests(meetingRequests);
                var refinedMeetingRequests = RefineMeetingRequests(sortedMeetingRequests);

                batchMeetingResponses = FinalizeMeetingResponses(refinedMeetingRequests);
            }

            return batchMeetingResponses;
        }

        public void DisplayMeetingRequests(IEnumerable<BatchMeetingResponses> batchMeetingResponses)
        {
            if (batchMeetingResponses.Any())
            {
                foreach (var batchMeetingResponse in batchMeetingResponses)
                {
                    if (batchMeetingResponse.MeetingResponses.Any())
                    {
                        Console.WriteLine(batchMeetingResponse.MeetingDate.ToString(Constants.DateTimeFormatWithDateOnly));
                        foreach (var meetingResponse in batchMeetingResponse.MeetingResponses)
                        {
                            Console.WriteLine($"{meetingResponse.MeetingStartTime.ToString(Constants.TimeSpanFormatWithoutSecond)} {meetingResponse.MeetingEndTime.ToString(Constants.TimeSpanFormatWithoutSecond)}");
                            Console.WriteLine(meetingResponse.EmployeeId);
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine(Constants.MeetingNotFoundMessage);
            }
        }

        private List<MeetingRequest> SortMeetingRequests(IEnumerable<MeetingRequest> meetingRequests)
        {
            var orderedMeetingRequests = meetingRequests.OrderBy(m => m.SubmissionDateTime).ToList();

            return orderedMeetingRequests;
        }

        private List<MeetingRequest> RefineMeetingRequests(IEnumerable<MeetingRequest> meetingRequests)
        {
            var finalMeetingRequests = new List<MeetingRequest>();

            foreach (var meetingRequest in meetingRequests)
            {
                if (meetingRequest.IsNotOverlapIn(finalMeetingRequests))
                {
                    finalMeetingRequests.Add(meetingRequest);
                }
            }

            return finalMeetingRequests;
        }

        private List<BatchMeetingResponses> FinalizeMeetingResponses(IEnumerable<MeetingRequest> meetingRequests)
        {
            var groupByMeetingRequests = meetingRequests
                .OrderBy(m => m.StartDateTime)
                .GroupBy(m => new { Day = m.StartDateTime.Day, Month = m.StartDateTime.Month, Year = m.StartDateTime.Year })
                .Select(grp => grp.ToList())
                .ToList();

            var allBatchMeetingResponses = new List<BatchMeetingResponses>();

            foreach (var groupByMeetingRequest in groupByMeetingRequests)
            {
                var meetingDate = groupByMeetingRequest.First().StartDateTime.Date;
                var meetingResponses = groupByMeetingRequest.Select(m => new MeetingResponse(
                    m.EmployeeId,
                    m.StartDateTime.TimeOfDay,
                    m.EndDateTime.TimeOfDay));

                var batchMeetingResponses = new BatchMeetingResponses(meetingDate, meetingResponses);
                allBatchMeetingResponses.Add(batchMeetingResponses);
            }


            return allBatchMeetingResponses;
        }
    }
}