﻿using MeetingManagementApplication.Application;
using MeetingManagementApplication.Infastructure;
using Microsoft.Extensions.DependencyInjection;

namespace MeetingManagementApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //setup our DI
            var serviceProvider = new ServiceCollection()
                .AddSingleton<IFileManager, FileManager>()
                .AddSingleton<IValidator, Validator>()
                .AddSingleton<IBookingService, BookingService>()
                .BuildServiceProvider();

            var fileName = "Sample.txt";
            var bookingService = serviceProvider.GetService<IBookingService>();
            var batchMeetingResponses = bookingService.ProcessBooking(fileName);

            bookingService.DisplayMeetingRequests(batchMeetingResponses);
        }
    }
}
