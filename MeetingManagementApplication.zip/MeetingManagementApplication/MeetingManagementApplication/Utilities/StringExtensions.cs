﻿namespace MeetingManagementApplication.Utilities
{
    public static class StringExtensions
    {
        public static string GetPathExtension(this string self)
        {
            var lastDotIndex = self.LastIndexOf(".");
            return lastDotIndex != -1 ? self.Substring(lastDotIndex + 1).Trim() : "";
        }
    }
}
