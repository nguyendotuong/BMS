﻿namespace MeetingManagementApplication.Utilities
{
    public static class Constants
    {
        public const int MeetingRequestNumberOfLines = 3;

        public const string DateTimeFormatWithDateOnly = "yyyy-MM-dd";
        public const string DateTimeFullFormat = "yyyy-MM-dd HH:mm:ss";
        public const string DateTimeFormatWithoutSecond = "yyyy-MM-dd HH:mm";

        public const string TimeSpanFormatWithoutSecond = @"hh\:mm";

        public const string MeetingNotFoundMessage = "Meeting Not Found";
    }
}
