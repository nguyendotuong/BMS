﻿using System;
using System.Collections.Generic;

namespace MeetingManagementApplication.Domain
{
    public class BatchRequests
    {
        public TimeSpan WorkingStartTime { get; set; }
        public TimeSpan WorkingEndTime { get; set; }
        public IEnumerable<MeetingRequest> MeetingRequests { get; set; }

        public BatchRequests(TimeSpan start, TimeSpan end)
        {
            WorkingStartTime = start;
            WorkingEndTime = end;
        }
    }
}
