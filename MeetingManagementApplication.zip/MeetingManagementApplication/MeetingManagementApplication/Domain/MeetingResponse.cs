﻿using System;

namespace MeetingManagementApplication.Domain
{
    public class MeetingResponse
    {
        public string EmployeeId { get; set; }
        public TimeSpan MeetingStartTime { get; set; }
        public TimeSpan MeetingEndTime { get; set; }

        public MeetingResponse(string employeeId, TimeSpan start, TimeSpan end)
        {
            EmployeeId = employeeId;
            MeetingStartTime = start;
            MeetingEndTime = end;
        }
    }
}
