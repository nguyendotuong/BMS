﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MeetingManagementApplication.Domain
{
    public class MeetingRequest
    {
        public string EmployeeId { get; set; }
        public DateTime SubmissionDateTime { get; set; }

        public DateTime StartDateTime { get; set; }
        public int DurationInHour { get; set; }
        public DateTime EndDateTime => StartDateTime.AddHours(DurationInHour);

        public MeetingRequest(
            string employeeId,
            DateTime submissionDateTime,
            DateTime startDateTime,
            int durationInHour)
        {
            EmployeeId = employeeId;
            SubmissionDateTime = submissionDateTime;
            StartDateTime = startDateTime;
            DurationInHour = durationInHour;
        }

        public bool IsValidMeeting(TimeSpan workingStartTime, TimeSpan workingEndTime)
        {
            var startTime = StartDateTime.TimeOfDay;
            var endTime = EndDateTime.TimeOfDay;

            // Meeting start  time must not earlier than working Start Time
            if (TimeSpan.Compare(startTime, workingStartTime) < 0)
            {
                return false;
            }

            // Meeting start time must not later than working End Time
            if (TimeSpan.Compare(endTime, workingEndTime) > 0)
            {
                return false;
            }

            return true;
        }

        public bool IsNotOverlapIn(IEnumerable<MeetingRequest> meetingRequests)
        {
            var result = !meetingRequests.
                Any(x => DateTime.Compare(x.StartDateTime, EndDateTime) < 0 &&
                        DateTime.Compare(StartDateTime, x.EndDateTime) < 0);

            return result;
        }
    }
}
