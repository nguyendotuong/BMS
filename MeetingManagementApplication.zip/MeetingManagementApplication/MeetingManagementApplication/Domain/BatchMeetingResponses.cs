﻿using System;
using System.Collections.Generic;

namespace MeetingManagementApplication.Domain
{
    public class BatchMeetingResponses
    {
        public DateTime MeetingDate { get; set; }
        public IEnumerable<MeetingResponse> MeetingResponses { get; set; }

        public BatchMeetingResponses(DateTime meetingDate, IEnumerable<MeetingResponse> meetingResponses)
        {
            MeetingDate = meetingDate;
            MeetingResponses = meetingResponses;
        }
    }
}
