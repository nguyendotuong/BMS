﻿using EnsureThat;
using MeetingManagementApplication.Utilities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MeetingManagementApplication.Infastructure
{
    public interface IValidator
    {
        public bool ValidateFile(
            string fileName,
            out string errorMessage,
            out TimeSpan start,
            out TimeSpan end,
            out List<string> requestsContents);

        public bool ValidateMeetingRequestContents(
            List<string> meetingRequestContents,
            out string employeeId,
            out DateTime submissionDate,
            out DateTime meetingStartDate,
            out int durationInHour);
    }

    public class Validator : IValidator
    {
        private readonly IFileManager _fileManager;
        private const string TextFile = "txt";
        private const int WorkingTimesAmount = 2;
        private const int HourLength = 2;
        private const string Colon = ":";

        public Validator(IFileManager fileManager)
        {
            _fileManager = fileManager;
        }

        public bool ValidateFile(
            string fileName,
            out string errorMessage,
            out TimeSpan start,
            out TimeSpan end,
            out List<string> requestsContents)
        {
            Ensure.That(fileName, nameof(fileName)).IsNotNullOrWhiteSpace();

            errorMessage = string.Empty;
            start = new TimeSpan();
            end = new TimeSpan();
            requestsContents = new List<string>();

            var fileType = fileName.GetPathExtension();

            ////TODO: Implement Adapter, Factory Method pattern to handle others file such as csv or xls
            if (!fileType.Equals(TextFile, StringComparison.InvariantCultureIgnoreCase))
            {
                errorMessage = $"This method only supports {TextFile} file.";
                return false;
            }

            var filePath = Path.Combine(AppContext.BaseDirectory, fileName);
            if (!_fileManager.FileExists(filePath))
            {
                errorMessage = $"Cannot find the file expected at {filePath}";
                return false;
            }

            var firstLineOfFile = _fileManager.ReadFirstLine(filePath);
            if (string.IsNullOrEmpty(firstLineOfFile))
            {
                errorMessage = "Invalid Working Times.";
                return false;
            }

            var workingTimes = firstLineOfFile.Trim().Split(" ").ToArray();
            if (workingTimes.Length != WorkingTimesAmount)
            {
                errorMessage = "Invalid Working Times.";
                return false;
            }

            var workingStartimeString = workingTimes.First();
            var workingEndTimeString = workingTimes.Last();

            if (string.IsNullOrEmpty(workingStartimeString) ||
            string.IsNullOrEmpty(workingEndTimeString))
            {
                errorMessage = "Invalid Working Times.";
                return false;
            }

            var isValidWorkingStartTime = TimeSpan.TryParse(workingStartimeString.Insert(HourLength, Colon), out var workingStartTime);
            var isValidWorkingEndTime = TimeSpan.TryParse(workingEndTimeString.Insert(HourLength, Colon), out var workingEndTime);

            if (!isValidWorkingStartTime || !isValidWorkingEndTime)
            {
                errorMessage = "Invalid Working Times.";
                return false;
            }

            if (TimeSpan.Compare(workingStartTime, workingEndTime) >= 0)
            {
                errorMessage = "Invalid Working Times.";
                return false;
            }

            start = workingStartTime;
            end = workingEndTime;
            requestsContents = _fileManager.ReadSkipFirstLine(filePath).ToList();

            return true;
        }

        public bool ValidateMeetingRequestContents(
            List<string> meetingRequestContents,
            out string employeeId,
            out DateTime submissionDate,
            out DateTime meetingStartDate,
            out int durationInHour)
        {
            employeeId = string.Empty;
            submissionDate = DateTime.MinValue;
            meetingStartDate = DateTime.MinValue;
            durationInHour = 0;

            if (meetingRequestContents.Count != Constants.MeetingRequestNumberOfLines)
            {
                return false;
            }

            var firstLine = meetingRequestContents.First().Trim();
            var secondLine = meetingRequestContents.Skip(1).First().Trim();
            var thirdLine = meetingRequestContents.Last().Trim();

            if (string.IsNullOrEmpty(firstLine) ||
                string.IsNullOrEmpty(secondLine) ||
                string.IsNullOrEmpty(thirdLine))
            {
                return false;
            }
            var submissionValueString = firstLine;
            var startTimeValueString = thirdLine.Substring(0, Constants.DateTimeFormatWithoutSecond.Length);
            var durationValueString = thirdLine.Substring(
                Constants.DateTimeFormatWithoutSecond.Length + 1,
                thirdLine.Length - Constants.DateTimeFormatWithoutSecond.Length - 1);

            if (!DateTime.TryParseExact(
                    submissionValueString,
                    Constants.DateTimeFullFormat,
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.None,
                    out var submission) ||
            !DateTime.TryParseExact(
                    startTimeValueString,
                    Constants.DateTimeFormatWithoutSecond,
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.None,
                    out var startTime) ||
            !int.TryParse(durationValueString, out var duration)
            )
            {
                return false;
            }

            employeeId = secondLine;
            submissionDate = submission;
            meetingStartDate = startTime;
            durationInHour = duration;

            return true;
        }
    }
}
