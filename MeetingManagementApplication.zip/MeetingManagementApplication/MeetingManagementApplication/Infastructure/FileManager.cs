﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace MeetingManagementApplication.Infastructure
{
	public interface IFileManager
	{
		bool FileExists(string path);
		string ReadFirstLine(string path);
		IEnumerable<string> ReadSkipFirstLine(string path);
	}

	public class FileManager : IFileManager
	{
		public bool FileExists(string path) => File.Exists(path);

		public string ReadFirstLine(string path)
        {
			return File.ReadLines(path).First();
		}

		public IEnumerable<string> ReadSkipFirstLine(string path)
		{
			return File.ReadLines(path).Skip(1).ToList();
		}
	}
}
